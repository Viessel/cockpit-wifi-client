cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "de",
  "language-direction": "ltr"
 },
 "Cockpit Wifi Client": [
  null,
  "Cockpit Bausatz"
 ],
 "Running on $0": [
  null,
  "Läuft auf $0"
 ],
 "Wifi Client": [
  null,
  "Bausatz"
 ],
 "Unknown": [
  null,
  "Unbekannt"
 ]
});
